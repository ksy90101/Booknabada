package com.booknabada.dao;

import org.springframework.stereotype.Repository;

import com.common.dao.AbstractDAO;

@Repository("sampleDAO")
public class SampleDAO extends AbstractDAO{

}
