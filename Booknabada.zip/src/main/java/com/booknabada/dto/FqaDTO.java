package com.booknabada.dto;

public class FqaDTO {
	int fqa_category;
	public int getFqa_category() {
		return fqa_category;
	}

	public void setFqa_category(int fqa_category) {
		this.fqa_category = fqa_category;
	}

	String fqa_answer, fqa_qustion;

	public String getFqa_answer() {
		return fqa_answer;
	}

	public void setFqa_answer(String fqa_answer) {
		this.fqa_answer = fqa_answer;
	}

	public String getFqa_qustion() {
		return fqa_qustion;
	}

	public void setFqa_qustion(String fqa_qustion) {
		this.fqa_qustion = fqa_qustion;
	}

	
}
