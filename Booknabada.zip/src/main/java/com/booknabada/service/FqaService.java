package com.booknabada.service;

import java.util.List;

import com.booknabada.dto.FqaDTO;

public interface FqaService {

	List<FqaDTO> board() throws Exception;

}
