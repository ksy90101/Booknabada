package com.booknabada.service;

public interface SampleService {

}
