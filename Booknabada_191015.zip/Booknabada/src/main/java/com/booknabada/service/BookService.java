package com.booknabada.service;

import com.booknabada.dto.BookDTO;

public interface BookService {

	void bookAddAction(BookDTO dto) throws Exception;


}
